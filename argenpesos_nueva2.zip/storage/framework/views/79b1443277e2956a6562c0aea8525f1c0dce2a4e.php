<div class="animated fadeIn">
<section id="form">
	<div class="row">
		<div class="first col-lg-5 text-center">
			<ul class="margin-top-60">
				<li><h1><b>HOY MISMO,</b> <br> CON O SIN VERAZ</h1></li>
				<li class="margin-top-25"><a href="" class="big border-btn red margin-top-50">SACÁ TU PRESTAMO</a> <img class="" src="<?php echo asset("storage/img/next-arrow.png")?>" alt="" style="padding-left:5px"></li>
				<li class="margin-top-25"><h3>Hasta $30.000 en 12 cuotas</h3></li>
			
			</ul>
			
			

		</div>
		<div class="col-lg-6 form-cont">
			<form id="form-home" class="text-left">
				<h1 class="red cursive">¡Empecemos!</h1>
				<h2 class="margin-top-5">
					<img src="<?php echo asset("storage/img/next-arrow-orange.png")?>" alt="">
					DATOS PERSONALES:
				</h2>
				<div class="row margin-top-25">
					<div class="col-sm-6">
						<input type="text" class="form-control" placeholder="Nombre" id="nombre">
						<div class="error" id="nombre-error">Ingrese un nombre valido</div>
					</div>
					<div class="col-sm-6">
						<input type="text" class="form-control" placeholder="Apellido" id="apellido">
						<div class="error" id="apellido-error">Ingrese un apellido valido</div>
					</div>
				</div>
				<div class="row margin-top-25">
					<div class="col-sm-6">
						<div class="col-sm-4  col-xs-12 padding-0">
							<select name="" id="cod_area" class="float-left" id="cod_area">
								<?php echo $__env->make('inc.options_cod_area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</select>
							<div class="error" id="cod-area-error">Ingrese un codigo area valido</div>
						</div>
						<div class="col-sm-2 col-xs-2 padding-0">
							<input type="text" name="fix-celular" id="fix-celular" value="15" disabled="disabled" class="form-control">
						</div>
						<div class="col-sm-6 col-xs-10 padding-0">
							<input type="number" class="form-control" id="telefono" placeholder="Telefono ">
						</div>
							
							
							
						
						
					</div>
					<div class="col-sm-6">
						
						<input type="number" class="form-control float-left" placeholder="DNI (sin puntos)" id="dni">
						<div class="error" id="dni-error">Ingrese un documento valido</div>
					</div>
				</div>

				<div class="row margin-top-25">
					<div class="col-sm-12">
						<input type="text" class="form-control" id="mail" placeholder="Mail">
						<div class="error" id="mail-error">Ingrese un mail valido</div>
					</div>
				</div>
				<div class="row  margin-top-35">
					<div class="btn-row">
						<a goTo="saca_tu_prestamo2" id="form-home-btn" class="border-btn red text-center float-right">SACÁ TU  PRÉSTAMO</a>
					
					</div>
				</div>
			</form>
		</div>
	</div>
</section>

<section id="como-funciona" class="text-center margin-top-100">
	<h1 class="blue">¿CÓMO <b>FUNCIONA?</b></h1>
	<img style="width: 20px" class="center-block" src="<?php echo asset("storage/img/arrow.jpg")?>" alt="">
	

	   <?php $__env->startComponent('comp.adelantos_creditos_online'); ?>
        <?php $__env->slot('class'); ?>
        margin-top-35
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
	


	<section id="creditos-sucursales" class="step-by-step margin-top-60 bk-grey padding-top-47 padding-bottom-47">
		<h2 class="red">CRÉDITOS EN <b>SUCURSALES</b></h2>
		<h4 class="margin-top-10">En 3 simples pasos</h4>
		<ul class="flex center-block margin-top-50">
			<li>
				<img src="<?php echo asset("storage/img/cs-step-1.png")?>" alt="">
				<h4><b>1.</b> Vení  a nuestra sucursal</h4>
			</li>
			<li class="line">
				<img src="<?php echo asset("storage/img/line.png")?>" alt="">
			</li>
			<li>
				<img src="<?php echo asset("storage/img/cs-step-2.png")?>" alt="">
				<h4><b>2.</b> Presentá la documentación <br> y te aprobamos la solicitud</h4>
			</li>
			<li class="line">
				<img src="<?php echo asset("storage/img/line.png")?>" alt="">
			</li>
			<li>
				<img src="<?php echo asset("storage/img/cs-step-3.png")?>" alt="">
				<h4><b>3.</b> RECIBÍ TU DINERO <br> <b> ¡EN EL ACTO! </b></h4>
			</li>
		</ul>
		

		<a goTo="sucursales" class="spa-btn border-btn red center-block margin-top-25" target="_blank">NUESTRAS SUCURSALES</a>


	</section>



</section>
<section id="banner" class="">
	<div class="owl-one owl-carousel owl-theme slider" id="owl-1">
		<div>
			<img src="<?php echo asset("storage/img/banner_2.png")?>" alt="">
		</div>
		<div>
			<img src="<?php echo asset("storage/img/banner.jpg")?>" alt="">
		</div>
	</div>

</section>

<?php $__env->startComponent('comp.contacto'); ?>
	<?php $__env->slot('class'); ?>
    bk-grey 

    padding-top-98 
	<?php $__env->endSlot(); ?>
	
<?php echo $__env->renderComponent(); ?>

</div>

<script type="text/javascript" src="<?php echo asset("OwlCarousel2-2.3.4/dist/owl.carousel.min.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("js/slider.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("js/routerAjax.js")?>"></script>
<script>


	  var soloLetrasYEspacios= /^[a-zA-Z\s]*$/; 
      var soloNumeros=/^[0-9]*$/;
       var nombre_esta_validado=false;

       var dni_esta_validado=false;

    var apellido_esta_validado=false;

    var celular_esta_validado=false;

    var email_esta_validado=false;
  var cod_area_esta_validado = false;
      var emailValido=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;


// FIXTURE
$('#form-home-btn').not("#cerrarMenu").click(function (e) {

  var url = $(this).attr('goTo');
  	
  var nombre = $("#form-home #nombre").val();
  var apellido = $("#form-home #apellido").val();
  var codArea = $("#form-home #cod_area").val();
  var dni = $("#form-home #dni").val();
  var telefono = $("#form-home #telefono").val();
  var mail = $("#form-home #mail").val();




             

                if(nombre_esta_validado==false){



                    $("#nombre").removeClass('border-color-green');

                    $("#nombre").addClass('border-color-red');


                    $("#nombre-error").fadeIn();

                }



                if(apellido_esta_validado==false){



                    $("#apellido").removeClass('border-color-green');

                    $("#apellido").addClass('border-color-red');

                    $("#apellido-error").fadeIn();

                }



                if(dni_esta_validado==false){



                    $("#dni").removeClass('border-color-green');

                    $("#dni").addClass('border-color-red');

                    $("#dni-error").fadeIn();

                }

                if(cod_area_esta_validado==false){



                    $("#codigo_area").removeClass('border-color-green');

                    $("#codigo_area").addClass('border-color-red');

                    $("#cod-area-error").fadeIn();



                }




                if(celular_esta_validado==false){



                    $("#celular").removeClass('border-color-green');

                    $("#celular").addClass('border-color-red');

                    $("#celular-error").fadeIn();


                }



                if(email_esta_validado==false){



                    $("#mail").removeClass('border-color-green');

                    $("#mail").addClass('border-color-red');

                    $("#mail-error").fadeIn();

                }





              
 

      if(nombre_esta_validado==true&&apellido_esta_validado==true&&dni_esta_validado==true&&cod_area_esta_validado==true&&celular_esta_validado==true&&email_esta_validado==true){



    $("#content").html('<div id="preloader" ><div class="spinner-sm spinner-sm-1" id="status"> </div></div>');


    e.preventDefault();

     $.ajax({
       type: "GET",
       data:{nombre:nombre,apellido:apellido,dni:dni,telefono:telefono,mail:mail,codArea:codArea},
       url: url,
       dataType: "html",
       scriptCharset: "ISO-8859-1",
       success: function(msg){


            $('#status').fadeOut(); // will first fade out the loading animation 
            $('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 

            $('body').delay(350).css({'overflow-y':'visible'});

              $("#content").html(msg);

              var cosa = $('#prestamo').attr('id');


              if(cosa == "prestamo"){
                $("#content").css("margin-top",0);
                $("header").fadeOut();
              }else{
                $("#content").css("margin-top","");
                $("header").fadeIn();
              }

          



          

        }
   
});



}
});



$("#form-home #nombre").keyup(function(){



        var nombre=$("#form-home  #nombre").val();



        if(nombre.length<4||nombre.search(soloLetrasYEspacios)){



            $("#form-home #nombre").removeClass('border-color-green');

            $("#form-home #nombre").addClass('border-color-red');

            $("#form-home #nombre-error").fadeIn();

            nombre_esta_validado=false;





        }else{



            $("#form-home #nombre").removeClass('border-color-red');


            $("#form-home #nombre").addClass('border-color-green');

            $("#form-home #nombre-error").fadeOut();

            nombre_esta_validado=true;



        }

    });



    $("#form-home #apellido").keyup(function(){



        var apellido=$("#form-home #apellido").val();



        if(apellido.length<3||apellido.search(soloLetrasYEspacios)){





            $("#form-home #apellido").removeClass('border-color-green');

            $("#form-home #apellido").addClass('border-color-red');
            
            apellido_esta_validado=false;

            $("#form-home #apellido-error").fadeIn();



        }else{


            $("#form-home #apellido").removeClass('border-color-red');

            $("#form-home #apellido").addClass('border-color-green');

            apellido_esta_validado=true;

            $("#form-home #apellido-error").fadeOut();



        }



    });

    $("#form-home #cod_area").change(function(){

        var celular = $("#telefono").val();
        var codAreaLenght = $("#cod_area").val();
        var position = celular.indexOf("15");

        if(codAreaLenght == "null"){
            $("#form-home #cod_area").removeClass('border-color-green');
            $("#form-home #cod_area").addClass("border-color-red");

            cod_area_esta_validado = false;


            $("#form-home #cod-area-error").fadeIn();



        }else{
            
            
            $("#form-home #cod_area").removeClass('border-color-red');
            $("#form-home #cod_area").addClass("border-color-green");

            cod_area_esta_validado = true;


            $("#cod-area-error").fadeOut();   

        }


        if(position==0){



                var newStr="";



                newStr = celular.replace("15","");



                $("#telefono").val(newStr);

        }

       

        var maxChars = 10-codAreaLenght.length;

        if ($("#form-home #telefono").val().length > maxChars) {

            $("#form-home #telefono").val($("#telefono").val().substr(0, maxChars));

            

            var celular=$("#form-home #telefono").val();

        }



         if(celular.length!=maxChars||celular.search(soloNumeros)){


            $("#form-home #telefono").removeClass('border-color-green');

            $("#form-home #telefono").addClass('border-color-red');

             $("#fix-celular").removeClass('border-color-green');

            $("#fix-celular").addClass('border-color-red');


            $("#telefono-error").fadeIn();


           




            celular_esta_validado=false;



        }else{



               
            $("#form-home #telefono").removeClass('border-color-red');

            $("#form-home #fix-celular").removeClass('border-color-red');

            $("#form-home #telefono").addClass('border-color-green');

            $("#form-home #fix-celular").addClass('border-color-green');

            celular_esta_validado=true;

            $("#telefono-error").fadeOut();

        }





    });





                

                

    $("#form-home #telefono").keyup(function(){

        var celular = $("#form-home #telefono").val();

        var codAreaLenght = $("#form-home #cod_area").val();




        var position = celular.indexOf("15");



        if(position==0){



                var newStr="";



                newStr = celular.replace("15","");



                $("#form-home #telefono").val(newStr);

        }

       

        var maxChars = 10-codAreaLenght.length;

        if ($(this).val().length > maxChars) {

            $(this).val($(this).val().substr(0, maxChars));

            

            var celular=$(this).val();

        }



         if(celular.length!=maxChars||celular.search(soloNumeros)){





             $("#form-home #telefono").removeClass('border-color-green');

            $("#form-home #telefono").addClass('border-color-red');

            $("#form-home #fix-celular").removeClass('border-color-green');

            $("#form-home #fix-celular").addClass('border-color-red');
            



            $("#telefono-error").fadeIn();





            celular_esta_validado=false;



        }else{



            $("#form-home #telefono").removeClass('border-color-red');


            $("#form-home #telefono").addClass('border-color-green');

            $("#form-home #fix-celular").removeClass('border-color-red');


            $("#form-home #fix-celular").addClass('border-color-green');



            $("#form-home #telefono-error").fadeOut();


            celular_esta_validado=true;



        }



    });

     $("#mail").keyup(function(){

    

        var email=$("#mail").val();

    

      if(email.length<3||email.search(emailValido)){

        $("#mail-check-icon").fadeOut();

        $("#mail-error-icon").fadeIn();

        $("#mail").removeClass('border-color-green');

        $("#mail").addClass('border-color-red');


        $("#mail-error").fadeIn();
       

        email_esta_validado=false;                    

        }else{

            $("#mail-error-icon").fadeOut();

            $("#mail-check-icon").css("display","block");

            $("#mail").removeClass('border-color-red');


         $("#mail").addClass('border-color-green');

            $("#mail-error").fadeOut();

            email_esta_validado=true;

        }

    });

      $("#dni").keyup(function(){

    

        var dni=$("#dni").val();



        var maxChars = 8;

        if ($(this).val().length > maxChars) {

            $(this).val($(this).val().substr(0, maxChars));

            

            var dni=$(this).val();

        }



      if(dni.length<7||dni.length>8||dni.search(soloNumeros)){



        



            $("#dni").removeClass('border-color-green');

            $("#dni").addClass('border-color-red');

 

            dni_esta_validado=false;

            $("#dni-error").fadeIn();

        }else{




            $("#dni").removeClass('border-color-red');


            $("#dni").addClass('border-color-green');

            dni_esta_validado=true;


            $("#dni-error").fadeOut();



        }

    });











</script><?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva\resources\views/home.blade.php ENDPATH**/ ?>
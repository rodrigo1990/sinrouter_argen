<b>Monto Solicitado:</b> $<?php echo e($consulta->valor_monto); ?><br>
<b>Nombre:</b> <?php echo e($consulta->nombre); ?><br>
<b>Apellido:</b> <?php echo e($consulta->apellido); ?><br>
<b>DNI:</b><?php echo e($consulta->dni); ?><br>
<b>Sexo:</b><?php echo e($consulta->sexo); ?><br>
<b>Codigo de area:</b><?php echo e($consulta->codigo_area); ?><br>
<b>Celular:</b> 15-<?php echo e($consulta->celular); ?><br>
<b>Fecha de Nacimiento:</b> <?php echo e($consulta->fecha_nacimiento); ?><br>
<b>Mail:</b> <?php echo e($consulta->mail); ?><br>
<b>Localidad:</b> <?php echo e($consulta->localidad); ?><br>
<b>Provincia:</b> <?php echo e($consulta->provincia); ?><br>
<b>Empleador:</b> <?php echo e($consulta->empleador); ?><br>
<b>Sueldo:</b> $<?php echo e($consulta->sueldo); ?><br>
<b>Banco:</b> <?php echo e($consulta->banco); ?><br><?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva\resources\views/mails/mail_admin.blade.php ENDPATH**/ ?>
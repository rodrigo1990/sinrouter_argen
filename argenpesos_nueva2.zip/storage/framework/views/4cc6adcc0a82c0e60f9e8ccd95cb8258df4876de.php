<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="initial-scale=1">
	<title>Argenpesos | ¡Saca tu prestamo! </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo asset("bootstrap-3.3.7-dist/css/bootstrap.min.css")?>"/>
	<link rel="stylesheet" href="<?php echo asset("css/estilos.css")?>">
	<link rel="stylesheet" href="<?php echo asset("css/animate.css")?>">
	<link rel="stylesheet" href="<?php echo asset("OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css")?>">
	<link rel="stylesheet" href="<?php echo asset("OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css")?>">
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="<?php echo asset("css/rangeslider.css")?>">
	<link rel="stylesheet" href="<?php echo asset("css/wsp-chat.css")?>">
	<?php echo $__env->yieldContent('estilos'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body <?php echo $__env->yieldContent('bodyclass'); ?>>
	<!-- PRELOADER AL CARGAR -->
	<div id="preloader"><div class="spinner-sm spinner-sm-1" id="status"> </div></div>
	

<?php echo $__env->yieldContent('content'); ?>


<!-- wsp-chat -->

    <div id="interfaceForm" class="interfaceForm animated fadeInUp" style="display:none">
    <div class="interfaceFormHeader text-left">
            <img src="<?php echo asset("storage/img/wsp-chat/whatsapp-logo-header.svg")?>" alt="">
            <div class="minimize" style="float:right;margin-right:5%;cursor:pointer" onClick="cerrarInterfaceForm()">
            <i class="fas fa-times" style="font-size: 20px;margin-top: 57%;"></i>
            </div>



        
    </div>
    <div class="interfaceFormBody ">
        <h3 class="title">Completá con tus datos</h3>
        <form action="" method="POST">
            <input type="text" name="nombre" id="nombre-wsp" class="form-control" placeholder="Nombre" required>
            <div class="error" id="nombre-error">Ingrese un nombre</div>
            <br>
            <input type="text" name="telefono" id="telefono-wsp" class="form-control" placeholder="Numero" required>
            <div class="error" id="telefono-error">Ingrese un telefono valido</div>
            <br>
            <input type="text" name="email" id="email-wsp" class="form-control" placeholder="Email" required>
            <div class="error" id="email-error-wsp">Ingrese un email valido</div>
            <br>
            <a class="btn btn-primary" onClick="enviarWsp();" ><h3>INICIAR CHAT</h3></a>
            <br>
        </form>
    </div>
</div>

<div id="interfaceFormBtn" class="interfaceFormBtn animated rollIn " style="cursor:pointer" onClick="abrirInterfaceForm();">
    <img style="display: inline-block;width:24px;height: 24px; margin-top: -7px; margin-right: 4px;" src="<?php echo asset("storage/img/wsp-chat/whatsapp-logo.svg")?>" alt="">
    <h3 style="display: inline-block;">CONSULTANOS</h3>
</div>  

<!-- /wsp-chat -->


<script type="text/javascript" src="<?php echo asset("js/jquery.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("bootstrap-3.3.7-dist/js/bootstrap.min.js")?>"></script>

<script type="text/javascript" src="<?php echo asset("js/manejoDeMenus.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("js/routerAjax.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("js/whatsapp-message.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("js/wspChatInterface.js")?>"></script>
<script type="text/javascript" src="<?php echo asset("js/enviarWsp.js")?>"></script>
 <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBkne1gpPfJ0B3KrE4OQURwPi492LDjg8g">
    </script>
    <script>
    		$(window).on('load', function() { // makes sure the whole site is loaded 
			
			$('#status').fadeOut(); // will first fade out the loading animation 
			$('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
			$('body').delay(350).css({'overflow-y':'visible'});

		});
    </script>
    
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva\resources\views/layouts/main.blade.php ENDPATH**/ ?>
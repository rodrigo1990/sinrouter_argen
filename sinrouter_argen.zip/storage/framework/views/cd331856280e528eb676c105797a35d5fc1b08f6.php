
<h1>PETICION DE TRABAJO</h1>

<b>Nombre:</b> <?php echo e($consulta->nombre); ?><br>
<b>Apellido:</b> <?php echo e($consulta->apellido); ?><br>
<b>DNI:</b> <?php echo e($consulta->dni); ?><br>
<b>Telefono:</b> <?php echo e($consulta->telefono); ?><br>
<b>Mail:</b> <?php echo e($consulta->mail); ?><br>
<b>Comentarios:</b> <?php echo e($consulta->comentarios); ?><br>


<?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva2\resources\views/mails/TrabajaConNosotros.blade.php ENDPATH**/ ?>
<?php $__env->startSection('estilos'); ?>
<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<div class="bk-landing">
        <div class="row">
            <h1><b>TU CRÉDITO ESTÁ</b> <br>SIENDO ANALIZADO</h1>
            <div class="subtitle">
                <h2>EN BREVE NOS CONTACTAREMOS CON VOS</h2>
            </div>
        </div>


</div>

<?php $__env->startComponent('comp.contacto'); ?>
    <?php $__env->slot('class'); ?>
    bk-grey 
    
    padding-top-77 
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('color'); ?>
    color:#333;
    <?php $__env->endSlot(); ?>
    
<?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('comp.footer'); ?>
        <?php $__env->slot('class'); ?>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('color'); ?>
        <?php $__env->endSlot(); ?>
            <?php $__env->slot('terminos'); ?>
                
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $("#content").css('margin-top',0);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitHub\sinrouter_argen\resources\views/landing-mail/credito_pre_aprobado.blade.php ENDPATH**/ ?>
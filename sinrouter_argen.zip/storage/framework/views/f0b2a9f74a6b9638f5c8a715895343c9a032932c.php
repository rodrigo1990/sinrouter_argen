<section id="contacto" class=" text-center padding-80 bk-white">
	<h1 class="blue"><b>CONTACTO</b></h1>
	<ul class="flex center-block margin-top-25">
		<li>
			<img src="<?php echo asset("storage/img/con-icon-1.png")?>" alt="">
			<h4><b>Mail</b> <br> info@argenpesos.com.ar</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-2.png")?>" alt="">
			<h4><b>TELÉFONO</b> <br> info@argenpesos.com.ar</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-3.png")?>" alt="">
			<h4><b>WHATSAPP</b> <br> 011-3241-4878</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-4.png")?>" alt="">
			<h4><b>FACEBOOK</b> <br> /argenpesos</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-5.png")?>" alt="">
			<h4><b>INSTAGRAM</b> <br> @argenpesos</h4>
		</li>
	</ul>

</section><?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva\resources\views/inc/contacto.blade.php ENDPATH**/ ?>
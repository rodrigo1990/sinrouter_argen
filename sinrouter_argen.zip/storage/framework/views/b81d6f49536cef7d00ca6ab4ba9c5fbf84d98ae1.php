
<h1>PETICION DE COMERCIALIZACION</h1>

<b>Nombre:</b> <?php echo e($consulta->nombre); ?><br>
<b>Apellido:</b> <?php echo e($consulta->apellido); ?><br>
<b>DNI:</b> <?php echo e($consulta->dni); ?><br>
<b>Provincia:</b> <?php echo e($consulta->provincia); ?><br>
<b>Localidad:</b> <?php echo e($consulta->localidad); ?><br>
<b>
Cuenta con local de venta al publico:</b> <?php echo e($consulta->venta); ?><br>
<b>Comentarios:</b> <?php echo e($consulta->comentarios); ?><br>

<?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva\resources\views/mails/ConvertiteEnComercializador.blade.php ENDPATH**/ ?>
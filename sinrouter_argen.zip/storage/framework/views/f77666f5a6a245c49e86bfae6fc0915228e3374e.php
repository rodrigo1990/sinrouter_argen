<?php 
require_once('Clases/Novedad.php'); 

$nov  = new Novedad();


?>



<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<section id="club_argenpesos" class="animated fadeIn margin-bottom-100">
<div class="row ">
	<h1 class="text-center margin-top-50"><b>RESPONSABILIDAD</b> SOCIAL</h1>
</div>


  <?php 

    $nov->listarNovedadesUser();

   ?>





</section>

<?php $__env->startComponent('comp.contacto'); ?>
	<?php $__env->slot('class'); ?>
	bk-blue
	<?php $__env->endSlot(); ?>
	
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('comp.footer'); ?>
  <?php $__env->slot('class'); ?>
  <?php $__env->endSlot(); ?>
  
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<!-- FANCYBOX -->
<script type="text/javascript" src="<?php echo asset("storage/js/jquery.mousewheel-3.0.6.pack.js")?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.4/jquery.fancybox.min.js"></script>
<!-- FANCY BOX -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.4/jquery.fancybox.min.css" />
<script type="text/javascript">
  $(document).ready(function() {
    $('.fancybox').fancybox();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitHub\argenpesos_nueva2\resources\views/resp_social.blade.php ENDPATH**/ ?>
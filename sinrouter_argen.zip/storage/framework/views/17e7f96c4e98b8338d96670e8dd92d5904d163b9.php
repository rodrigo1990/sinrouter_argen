<?php $__env->startSection('estilos'); ?>
<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<div class="bk-landing">
        <div class="row rechazado">
            <h1>LAMENTAMOS INFORMARTE QUE POR EL MOMENTO <br> <b>NO TENEMOS UN PRÉSTAMO ONLINE <br></b>DISPONIBLE PARA VOS</h1>
        </div>


</div>

<div class="row rechazado-aviso margin-top-80">
    <div class="container">
        <h1 class="text-center"><b>PARA SABER</b> SI CALIFICÁS</h1>

        <p class="text-center">Para un préstamo en nuestras sucursales <br> realizá tu consulta al</p>

        <h3 class="text-center"><img src="<?php echo asset("storage/img/solicitud/icon-bg-01.png")?>" class="" alt=""> 0800-222-2743 o al <img src="<?php echo asset("storage/img/solicitud/icon-bg-02.png")?>" class="" alt=""> 11-3241-4878</h3>
    </div>
</div>

<?php $__env->startComponent('comp.contacto'); ?>
    <?php $__env->slot('class'); ?>
    bk-grey 
    
    padding-top-77 
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('color'); ?>
    color:#333;
    <?php $__env->endSlot(); ?>
    
<?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('comp.footer'); ?>
        <?php $__env->slot('class'); ?>
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('color'); ?>
        <?php $__env->endSlot(); ?>
            <?php $__env->slot('terminos'); ?>
                
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $("#content").css('margin-top',0);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitHub\sinrouter_argen\resources\views/landing-mail/credito_rechazado.blade.php ENDPATH**/ ?>
	<option value="null">Banco donde depositan tu sueldo</option>
	<option value="no_poseo">No poseo cuenta bancaria</option>
		                <option value="nacion">Banco Naci&oacute;n</option>
		                <option value="patagonia">Banco Patagonia</option>
		                <option value="santander">Banco Santander R&iacute;o</option>
		                <option>Banco Ciudad</option>
		                <option>Banco Columbia</option>
		                <option>Banco Comafi</option>
		                <option>Banco Corrientes</option>
		                <option>Banco Credicoop</option>
		                <option>Banco de Formosa</option>
		                <option>Banco de La Pampa</option>
		                <option>Banco Provincia de Buenos Aires</option>
		                <option value="chubut">Banco Provincia de Chubut</option>
		                <option>Banco Provincia de C&oacute;rdoba</option>
		                <option>Banco Provincia de Neuqu&eacute;n</option>
		                <option>Banco de Tierra del Fuego</option>
		                <option>Banco Finansur</option>
		                <option>Banco Franc&eacute;s</option>
		                <option>Banco Galicia</option>
		                <option>Banco Hipotecario</option>
		                <option>Banco Ita&uacute;</option>
		                <option>Banco Industrial</option>
		                <option>Banco Macro</option>
		                <option>Banco Municipal de Rosario</option>
		                <option>Banco Piano</option>
		                <option>Banco Regional de Cuyo</option>
		                <option>Banco San Juan</option>
		                <option>Banco Santa Cruz</option>
		                <option>Banco Santa Fe</option>
		                <option>Banco de Santiago del Estero</option>
		                <option>Banco Supervielle</option>
		                <option>Banco Tucum&aacute;n</option>
		                <option>Banco Citibank</option>
		                <option>Banco HSBC</option>
		                <option>Nuevo Banco de Entre R&iacute;os</option>
		                <option>Nuevo Banco de la Rioja</option>
		                <option>Nuevo Banco del Chaco</option>
		                <option>Standard Bank /ICBC</option>
		                <option>OTRO</option><?php /**PATH C:\xampp\htdocs\GitHub\sinrouter_argen\resources\views/inc/options_bancos.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
	body{
		background-color:#f5f5f6; 
	}
</style>	
	<section id="consulta_tu_cuenta" class="">
		<div class=" bk-title">
			<h1><b>¡BIENVENIDO</b> CLIENTE!</h1>
		</div>
		<div class="row">
			<div class="container">
				<iframe src="/quiero-pagar-components/quiero-pagar-form.php" id="iFrame" frameborder="0" style="width:100%;height: 800px;"></iframe>
			</div>
		</div>

	</section>

	<?php $__env->startComponent('comp.contacto'); ?>
		<?php $__env->slot('class'); ?>
		bk-blue
		<?php $__env->endSlot(); ?>
		<?php $__env->slot('color'); ?>
			color:white;
		<?php $__env->endSlot(); ?>
		
	<?php echo $__env->renderComponent(); ?>


	<?php $__env->startComponent('comp.footer'); ?>
		<?php $__env->slot('class'); ?>
		<?php $__env->endSlot(); ?>
		
	<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitHub\sinrouter_argen\resources\views/consulta_tu_cuenta.blade.php ENDPATH**/ ?>
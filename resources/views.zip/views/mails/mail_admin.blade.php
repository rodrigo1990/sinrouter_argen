<b>Monto Solicitado:</b> ${{$consulta->valor_monto}}<br>
<b>Nombre:</b> {{$consulta->nombre}}<br>
<b>Apellido:</b> {{$consulta->apellido}}<br>
<b>DNI:</b> {{$consulta->dni}}<br>
<b>Sexo:</b> {{$consulta->sexo}}<br>
<b>Codigo de area:</b> {{$consulta->codigo_area}}<br>
<b>Celular:</b> 15-{{$consulta->celular}}<br>
<b>Fecha de Nacimiento:</b> {{$consulta->fecha_nacimiento}}<br>
<b>Mail:</b> {{$consulta->mail}}<br>
<b>Localidad:</b> {{$consulta->localidad}}<br>
<b>Provincia:</b> {{$consulta->provincia}}<br>
<b>Empleador:</b> {{$consulta->empleador}}<br>
<b>Sueldo:</b> ${{$consulta->sueldo}}<br>
<b>Banco:</b> {{$consulta->banco}}<br>
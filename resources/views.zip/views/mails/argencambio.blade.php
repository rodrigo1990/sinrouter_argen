
<h1>FORMULARIO ARGENCAMBIO</h1>

<b>Nombre:</b> {{$consulta->nombre}}<br>
<b>Apellido:</b> {{$consulta->apellido}}<br>
<b>Teléfono:</b> {{$consulta->telefono}}<br>

<b>Mail:</b> {{$consulta->mail}}<br>

<b>Consulta:</b> {{$consulta->consulta}}<br>


<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
</head>
<body>
	<table style='color: #1da3dd; font-size: 17px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;'>
		<tr><td><img src='http://legionvps.com/trabajos/argenpesos/imagenes/logo-mail-2.png' style='width: 100%; max-width: 240px;' /></td></tr>
		<tr><td><br />LAMENTAMOS INFORMARTE QUE POR EL MOMENTO NO TENEMOS UN PRÉSTAMO PARA VOS<br /><br /></td></tr>
		<tr>
          <td>
          Por cualquier consulta comunicate al:
 <h1 style='color: #1da3dd; font-size: 17px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;'>
          <img style='vertical-align:middle' src='http://www.legionvps.com/trabajos/argenpesos/img-form-solicitud/icon-bg-01.png'>
          0800-345-2733
          </h1>
 <a style='text-decoration:none;' href='https://api.whatsapp.com/send?phone=1126785266&text=Hola%20Argenpesos:%20me%20comunico%20por%20lo%20visto%20en%20el%20formulario%20de%20solicitar%20prestamo' target='_blank'>
          <h1 style='color: #1da3dd; font-size: 17px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;'>
          <h1 style='color: #1da3dd; font-size: 17px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;'>
          <img style='vertical-align:middle' src='http://www.legionvps.com/trabajos/argenpesos/img-form-solicitud/icon-bg-02.png'>
          11-6121-3894 
          </h1>
           </a>
<a style='text-decoration:none;' href='https://api.whatsapp.com/send?phone=1126785266&text=Hola%20Argenpesos:%20me%20comunico%20por%20lo%20visto%20en%20el%20formulario%20de%20solicitar%20prestamo' target='_blank'>
          <h1 style='color: #1da3dd; font-size: 17px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;'>
          <img style='vertical-align:middle' src='http://www.legionvps.com/trabajos/argenpesos/img-form-solicitud/icon-bg-02.png'>
          11-2678-5266
          </h1>
           </a>
          <a style='color: #1da3dd; text-decoration: none;' href='mailto:info@argenpesos.com.ar'>info@argenpesos.com.ar</a>
          <br />
          <br />
          </td>
          </tr>
          <tr><td style='font-size: 13px; color: #88898d; font-weight: normal;'>¡Saludos!<br /><br /><br /></td></tr>";
          </table>

    
    
</body>
</html>
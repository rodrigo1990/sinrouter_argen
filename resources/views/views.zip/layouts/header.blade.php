	<header id="menu-center" >
			<div  class="row">
				<div class="container-fluid">
					<div class="col-lg-2 col-md-2 hidden-sm hidden-xs ">
						<a href="index.php">
							<img class="logo" src="<?php echo asset("storage/img/logo.png")?>"></img> 

						</a>
					</div>

					<div class="col-lg-10 col-md-10 hidden-sm hidden-xs btn-cont">
						<ul id="nav">
							<li><a href="saca_tu_prestamo" class=" scroll-spy link-gal" data-offset="50" >SACA TU PRÉSTAMO</a></li>
							<li><a href="#quiero-ser-socio" class="scroll-spy" data-offset="-50">CONSULTÁ TU PRÉSTAMO</a></li>
							<li><a href="#cartilla"  data-toggle="modal" data-target="#cartilla-modal" >NUESTRAS SUCURSALES</a></li>

							<li><a href="#atencion-al-socio" class="scroll-spy" data-offset="50">QUIENES SOMOS</a></li>

							<li class="">
								
								<a href="" class="float-left rr-ss"><i class="fab fa-facebook-f"></i></a>


								<a href="" class="float-left rr-ss"><i class="fab fa-instagram"></i></a>
							</li>
							
						</ul>
					</div>

				</div>
				<div class="hidden-lg hidden-md col-sm-12 col-xs-12 text-center xs-row " style="">
					<a href="index.php">
						<img src="<?php echo asset("storage/img/logo.png")?>" width="150px"></img> 
					</a>
						<a id="abrirMenu">
							<i class="fa fa-bars"  id="abrirMenu"></i>
						</a>
					</div>
			</div>
		</header>
		<ul id="xsMenu" class="overlay-xs-menu menu">
			<div class="row">
				<a id="cerrarMenu"  class="close-menu-xs">
					<i class="fas fa-times"></i>
				</a>
			</div>
			<li><a href="" class="xs-btn" data-offset="50" >SACA TU PRÉSTAMO</a></li>
			<li><a href="" class="xs-btn" data-offset="-50">CONSULTÁ TU PRÉSTAMO</a></li>
			<li><a href="" class="xs-btn">NUESTRAS SUCURSALES</a></li>

			<li><a href="" class="xs-btn" data-offset="50">QUIENES SOMOS</a></li>
		</ul>
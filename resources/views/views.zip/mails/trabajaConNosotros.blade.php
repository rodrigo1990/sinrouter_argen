
<h1>PETICION DE TRABAJO</h1>

<b>Nombre:</b> {{$consulta->nombre}}<br>
<b>Apellido:</b> {{$consulta->apellido}}<br>
<b>DNI:</b> {{$consulta->dni}}<br>
<b>Telefono:</b> {{$consulta->telefono}}<br>
<b>Mail:</b> {{$consulta->mail}}<br>
<b>Comentarios:</b> {{$consulta->comentarios}}<br>



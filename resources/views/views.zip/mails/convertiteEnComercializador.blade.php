
<h1>PETICION DE COMERCIALIZACION</h1>

<b>Nombre:</b> {{$consulta->nombre}}<br>
<b>Apellido:</b> {{$consulta->apellido}}<br>
<b>DNI:</b> {{$consulta->dni}}<br>
<b>Provincia:</b> {{$consulta->provincia}}<br>
<b>Localidad:</b> {{$consulta->localidad}}<br>
<b>
Cuenta con local de venta al publico:</b> {{$consulta->venta}}<br>
<b>Comentarios:</b> {{$consulta->comentarios}}<br>


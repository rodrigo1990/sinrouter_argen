@extends('layouts.main')

@include('layouts.header')
@section('content')
	<iframe src="/home" id="iframe" class="float-left" name="iframe" target="iframe" frameborder="0"></iframe>
@stop


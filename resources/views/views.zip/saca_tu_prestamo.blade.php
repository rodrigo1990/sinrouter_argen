@extends('layouts.main')
@section('content')
<div class="row" id="prestamo-form">
	<div class="col-lg-6 col-md-6 col sm-8" style="text-align:center">
		<div style="text-align: left;">
				<a href="../index.php"><img src="<?php echo asset("storage/img/logo.png")?>" id="logo" class=""  alt=""></a>
		</div>
	    
	    <h1>HOY MISMO LLEVATE <br> <b>HASTA <span class="red">$30.000</span></b></h1>

	    <img src="<?php echo asset("storage/img/form-graphic.png")?>" class="center-block" alt="">
		
		<div class="bk-red padding-10 inline-block">
			<h3 >¡SUPER SIMPLE! ¡ÚNICO REQUISITO!</h3>
		</div>

		<div id="cobrarPorCuenta">
			<h3 class="">Cobrar por cuenta bancaria</h3>
			<p>Sueldo/Jubilaciones/Pensiones</p>	
		</div>


	</div><!-- col-lg-7 col-md-7 col sm-8 -->
	
	<div class="col-lg-6 col-md-6 col-sm-12 pattern form-cont">
	<div class="my-container">
	<form action="solicitud.php" method="POST" name="myForm" id="myForm">
	<h2 style="margin-top: 0;">
	<img src="<?php echo asset("storage/img/next-arrow-orange.png")?>" alt="">
	DATOS PERSONALES:</h2>		
			<div class="row ">
				
				<div class="col-lg-6 col-md-6 col-sm-12  col-xs-12">
	                    <input type="text" placeholder="Nombre" name="nombre" class="form-control" id="nombre">

	                    <div class="valid-feedback feedback-icon" id="nombre-check-icon">

	                        <i class="fa fa-check"></i>

	                    </div>

	                     <div class="invalid-feedback feedback-icon" id="nombre-error-icon">

	                        <i class="fa fa-times"></i>

	                    </div>


				</div>
				<div class="col-lg-6 col-md-6 col-xs-12">
						<input type="text" placeholder="Apellido" name="apellido" class="form-control" id="apellido">
	                     <div class="valid-feedback feedback-icon" id="apellido-check-icon">

	                        <i class="fa fa-check"></i>

	                    </div>

	                     <div class="invalid-feedback feedback-icon" id="apellido-error-icon">

	                        <i class="fa fa-times"></i>

	                    </div>
				</div>
			</div>
			<div class="row ">
				<div class="col-lg-6 col-md-6 col-xs-12">
					<input type="number" name="dni" id="dni" class="form-control" maxlength="8" placeholder="DNI (sin puntos)">
					<div class="valid-feedback feedback-icon" id="dni-check-icon">

	                        <i class="fa fa-check"></i>

	                    </div>

	                     <div class="invalid-feedback feedback-icon" id="dni-error-icon">

	                        <i class="fa fa-times"></i>

	                    </div>
				</div>
				<div class="col-lg-6 col-md-6 col-xs-12">
					
					<input type="radio" value="Masculino" name="sexo" class="float-left" checked>
					<p class="float-left">Masculino</p>
					
					<input type="radio" value="Femenino" name="sexo" class="float-left">
					<p class="float-left">Femenino</p>
				</div>
			</div>
			<div class="row ">
				<div class="col-lg-6 col-md-6 col-xs-12">
					<select  name="codigo_area" id="codigo_area"  class="form-control">
						@include('inc.options_cod_area')
					</select>
					</div>
					<div class="col-lg-6 col-md-6 col-xs-12">
	                    <input type="text" name="fix-celular" id="fix-celular" value="15" disabled="disabled" class="form-control">
						<input type="number" name="celular" id="celular" placeholder="Ej:46587925"  class="form-control">
						<div class="valid-feedback feedback-icon" id="celular-check-icon">

	                        <i class="fa fa-check"></i>

	                    </div>

	                     <div class="invalid-feedback feedback-icon" id="celular-error-icon">

	                        <i class="fa fa-times"></i>

	                    </div>
					</div>
				</div>
				<div class="row ">
					<div class="col-lg-12 col-md-12 col-xs-12">
						<input type="text" name="mail" id="email" placeholder="Email" class="form-control">
						<div class="error" id="mail-error">*Ingrese un email valido</div>
	                    <div class="valid-feedback feedback-icon" id="email-check-icon">

	                        <i class="fa fa-check"></i>

	                    </div>

	                     <div class="invalid-feedback feedback-icon" id="email-error-icon">

	                        <i class="fa fa-times"></i>

	                    </div>
					</div>
				</div>
				<div class="row ">
					<div class="col-lg-6 col-md-6 col-xs-12">
						<select  name="provincia" id="provincia"  class="form-control">
							<option value="0">Seleccione</option>
							 <option value='Buenos Aires'>Buenos Aires</option><option value='Capital Federal'>Capital Federal</option><option value='Catamarca'>Catamarca</option><option value='Chaco'>Chaco</option><option value='Chubut'>Chubut</option><option value='Cordoba'>Cordoba</option><option value='Corrientes'>Corrientes</option><option value='Entre Ríos'>Entre Ríos</option><option value='Formosa'>Formosa</option><option value='Jujuy'>Jujuy</option><option value='La Pampa'>La Pampa</option><option value='La Rioja'>La Rioja</option><option value='Mendoza'>Mendoza</option><option value='Misiones'>Misiones</option><option value='Neuquen'>Neuquen</option><option value='Rio Negro'>Rio Negro</option><option value='Salta'>Salta</option><option value='San Juan'>San Juan</option><option value='San Luis'>San Luis</option><option value='Santa Cruz'>Santa Cruz</option><option value='Santa Fe'>Santa Fe</option><option value='Santiago del Estero'>Santiago del Estero</option><option value='Tierra del Fuego'>Tierra del Fuego</option><option value='Tucuman'>Tucuman</option>					</select>
						<div class="error" id="provincia-error">*Ingrese una provincia</div>
					</div>
					<div class="col-lg-6 col-md-6 col-xs-12">
						<select  name="localidad" id="localidad"  class="form-control">
							<option value="0">Seleccione</option>
						</select>
						<div class="error" id="localidad-error">*Ingrese una localidad valida</div>
					</div>
				</div>
				<div class="row ">
					<div class="col-lg-6 col-md-6 col-xs-12">
						<select  name="banco"  class="form-control">
						 @include('inc.options_bancos')
						</select>
					</div>
					<div class="col-lg-6 col-md-6 col-xs-12">
						<select  name="empleador"  class="form-control">
							 <option value="Asignacion">Asig. Universal por hijo</option>
			                <option value="Cooperativa">Cooperativa</option>
			                <option value="Empleado_publico">Empleado Sector Público</option>
			                <option value="Empleado_privado">Empleado Sector Privado</option>
			                <option value="Monotributista">Autónomo/Monotributista</option>
			                <option value="Jubilado">Jubilado/Pensionado</option>
			                <option value="Sin_empleo">Sin Empleo</option>
						</select>
					</div>
				</div>
				<div class="row ">
				    <div class="col-lg-12 col-md-12 col-xs-12">
						<input placeholder="100000" type="number" name="sueldo" id="sueldo" class="form-control">
						<div class="error" id="sueldo-error">Ingrese un sueldo valido</div>
	                     <div class="valid-feedback feedback-icon" id="sueldo-check-icon">

	                        <i class="fa fa-check"></i>

	                    </div>

	                     <div class="invalid-feedback feedback-icon" id="sueldo-error-icon">

	                        <i class="fa fa-times"></i>

	                    </div>
					</div>
				</div>
					<div class="row text-center ">
						<h1 class="form-titles">¿<b>CUÁNTO</b> NECESITAS?</h1>
						<div>
					         <output></output>
						    <p style="float:left">$3.000</p>
						    <p style="float:right">$30.000</p></div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

								
						 		<input step="500" type="range" name="valor_monto" id="dinero" min="3000" max="30000" data-rangeslider>

						         <!--<p class="text-center" style="font-size:2rem;">Tu ingreso neto en mano debe ser de $10.000</p>-->

						</div>
					</div>
				<div class="row " style="padding-bottom: 0px;">
					<div class="col-lg-6 col-md-6 col-xs-12">

						<input type="radio" value="aceptado" id="terminos" name="terminos" class="float-left">
						<p class="float-left">Acepto los terminos y condiciones</p>
						<div class="error" id="terminos-error">*Acepte los terminos</div>
					</div>
					
					<div class="col-lg-6 col-md-6 col-xs-12">
						
						<a class="border-btn red float-right text-center" value="ENVIAR SOLICITUD" id="btn_enviar" style="cursor:pointer" onClick="myFunction()">ENVIAR SOLICITUD </a>
						
					</div>
				</div>	
				<div class="row ">
				
					<div class="col-lg-12 col-md-12 col-xs-12">
					<div
					id='recaptcha'
					class="g-recaptcha"
					data-sitekey="6Lcg21YUAAAAAFjfbU3ZWINWWcy_4pmu5WdyOrx9"
					data-callback="myFunction"
					>
					    
					</div>

	                <div class="msg-error" style="color:red;"></div>

				<div class="error" id="captcha-error">*Valide el captcha</div>
					</div>
				</div>
		</form>
		</div>
	</div>
</div>

	<div>
	@include('inc.adelantos_creditos_online')
	</div>
	@include('inc.footer')

@stop
@section('scripts')
<script type="text/javascript" src="<?php echo asset("js/validacionesSolicitarPrestamo.js")?>"></script>
@stop
@extends('layouts.main')


@section('content')

<section id="form">
	<div class="row">
		<div class="first col-lg-6 text-center">
			<ul>
				<li><h1><b>HOY MISMO</b> CON O SIN VERAZ</h1></li>
				<li class="margin-top-70"><a href="" class="big border-btn red margin-top-50">SACÁ TU PRESTAMO</a> <img class="" src="<?php echo asset("storage/img/next-arrow.png")?>" alt="" style="padding-left:5px"></li>
				<li class="margin-top-25"><h3>Hasta $30.000 en 12 cuotas</h3></li>
				<li class="margin-top-44"><a href="" class="big border-btn blue margin-top-50">PEDÍ TU ADELANTO</a><img class="" src="<?php echo asset("storage/img/next-arrow.png")?>" alt="" style="padding-left:15px"></li>
				<li class="margin-top-25"><h3>Hasta $8.000 en 3 cuotas</h3></li>
			</ul>
			
			

		</div>
		<div class="col-lg-6 form-cont">
			<form class="text-left">
				<h1 class="red cursive">¡Empecemos!</h1>
				<h2 class="margin-top-5">
					<img src="<?php echo asset("storage/img/next-arrow-orange.png")?>" alt="">
					DATOS PERSONALES:
				</h2>
				<div class="row margin-top-25">
					<div class="col-sm-6">
						<input type="text" class="form-control" placeholder="Nombre">
					</div>
					<div class="col-sm-6">
						<input type="text" class="form-control" placeholder="Apellido">
					</div>
				</div>
				<div class="row margin-top-25">
					<div class="col-sm-6">
						<input type="number" class="form-control" placeholder="Telefono celular">
					</div>
					<div class="col-sm-6">
						<input type="number" class="form-control" placeholder="DNI (Sin puntos)">
					</div>
				</div>

				<div class="row margin-top-25">
					<div class="col-sm-12">
						<input type="text" class="form-control" placeholder="Mail">
					</div>
				</div>
				<div class="row  margin-top-35">
					<div class="btn-row center-block">
						<a href="" class="border-btn red float-left text-center">QUIERO MI PRÉSTAMO</a>
						<a href="" class="border-btn blue float-left text-center margin-left-10">QUIERO MI ADELANTO</a>
					</div>
				</div>
			</form>
		</div>
	</div>
</section>

<section id="como-funciona" class="text-center margin-top-100">
	<h1 class="blue">¿COMO <b>FUNCIONA?</b></h1>
	<img style="width: 20px" class="center-block" src="<?php echo asset("storage/img/arrow.jpg")?>" alt="">
	

	@include('inc.adelantos_creditos_online')
	


	<section id="creditos-sucursales" class="step-by-step margin-top-100">
		<h2 class="red">CRÉDITOS EN <b>SUCURSALES</b></h2>
		<h4 class="margin-top-10">En 3 simples pasos</h4>
		<ul class="flex center-block margin-top-50">
			<li>
				<img src="<?php echo asset("storage/img/cs-step-1.png")?>" alt="">
				<h4><b>1.</b> Completá el formulario</h4>
			</li>
			<li class="line">
				<img src="<?php echo asset("storage/img/line.png")?>" alt="">
			</li>
			<li>
				<img src="<?php echo asset("storage/img/cs-step-2.png")?>" alt="">
				<h4><b>2.</b> Te contactamos en el día</h4>
			</li>
			<li class="line">
				<img src="<?php echo asset("storage/img/line.png")?>" alt="">
			</li>
			<li>
				<img src="<?php echo asset("storage/img/cs-step-3.png")?>" alt="">
				<h4><b>3.</b> Firmá  y te acreditamos el <br>dinero en tu cuenta</h4>
			</li>
		</ul>
		

		<a href="" class="border-btn red center-block margin-top-25">SACÁ TU PRÉSTAMO</a>


	</section>



</section>
<section id="banner" class="margin-top-100">
	<div class="owl-one owl-carousel owl-theme slider" id="owl-1">
		<div>
			<img src="<?php echo asset("storage/img/banner.jpg")?>" alt="">
		</div>
		<div>
			<img src="<?php echo asset("storage/img/banner.jpg")?>" alt="">
		</div>
	</div>

</section>


<section id="contacto" class="margin-top-100 text-center">
	<h1 class="blue"><b>CONTACTO</b></h1>
	<ul class="flex center-block margin-top-25">
		<li>
			<img src="<?php echo asset("storage/img/con-icon-1.png")?>" alt="">
			<h4><b>Mail</b> <br> info@argenpesos.com.ar</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-2.png")?>" alt="">
			<h4><b>TELÉFONO</b> <br> info@argenpesos.com.ar</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-3.png")?>" alt="">
			<h4><b>WHATSAPP</b> <br> 011-3241-4878</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-4.png")?>" alt="">
			<h4><b>FACEBOOK</b> <br> /argenpesos</h4>
		</li>
		<li>
			<img src="<?php echo asset("storage/img/con-icon-5.png")?>" alt="">
			<h4><b>INSTAGRAM</b> <br> @argenpesos</h4>
		</li>
	</ul>

</section>
@include('inc.footer')
@stop
